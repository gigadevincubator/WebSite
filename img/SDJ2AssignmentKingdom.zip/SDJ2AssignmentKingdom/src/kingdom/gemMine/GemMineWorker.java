package kingdom.gemMine;

import kingdom.Catalogue;
import kingdom.gemMine.gemDeposit.GemDeposit;
import kingdom.gemMine.gems.Valuable;

import java.util.Random;

public class GemMineWorker implements Runnable
{
    private Random random = new Random();
    private GemDeposit gemDeposit;

    public GemMineWorker(GemDeposit gemDeposit) {
        this.gemDeposit = gemDeposit;
    }

    private String mined() {
        int luck = random.nextInt(64);
        if (luck <= 10) {
            return "diamond";
        }
        else if (luck <=12 ) {
            return "ruby";
        }
        else if (luck <= 16) {
            return "salt";
        }
        else if (luck <= 20) {
            return "goldNugget";
        }
        else if (luck <= 32) {
            return "ironNugget";
        }
        else {
            return "coal";
        }
    }

    @Override
    public void run() {
        while (true) {
            Valuable valuable = GemMine.getValuable(mined());
            gemDeposit.put(valuable);

            try {
                Thread.sleep(random.nextInt(500)+5000);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
