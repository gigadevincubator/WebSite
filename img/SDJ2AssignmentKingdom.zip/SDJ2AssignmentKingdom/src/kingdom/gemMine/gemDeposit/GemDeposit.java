package kingdom.gemMine.gemDeposit;

import kingdom.gemMine.gems.Valuable;

public interface GemDeposit
{
    void put(Valuable valuable);
    Valuable take();
    boolean isEmpty();
    boolean isFull();
    int size();
}
