package kingdom.gemMine.gemDeposit;

import kingdom.gemMine.gems.Valuable;
import kingdom.utils.ArrayListQueue;
import kingdom.utils.QueueADT;

public class GemDepositBlockingQueue implements GemDeposit
{

    private QueueADT<Valuable> valuables = new ArrayListQueue<>();
    private final int MAX_CAPACITY;
    private final int MIN_CAPACITY;

    public GemDepositBlockingQueue(int maxCap) {
        MAX_CAPACITY = maxCap;
        MIN_CAPACITY = 0;
    }

    @Override
    public synchronized void put(Valuable valuable) {
        while (isFull()) {
            try {
                wait();
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        valuables.enqueue(valuable);
        notifyAll();
    }

    @Override
    public synchronized Valuable take() {
        while (isEmpty()) {
            try {
                wait();
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        Valuable valuable = valuables.dequeue();
        notifyAll();
        return valuable;
    }

    @Override
    public synchronized boolean isEmpty() {
        return valuables.size() <= MIN_CAPACITY;
    }

    @Override
    public synchronized boolean isFull() {
        return valuables.size() >= MAX_CAPACITY;
    }

    @Override
    public synchronized int size() {
        return valuables.size();
    }
}
