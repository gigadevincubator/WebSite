package kingdom.gemMine.gems;

public class IronNugget implements Valuable
{
  @Override public String getName()
  {
    return "Iron Nugget";
  }

  @Override public int getValue()
  {
    return 7;
  }
}
