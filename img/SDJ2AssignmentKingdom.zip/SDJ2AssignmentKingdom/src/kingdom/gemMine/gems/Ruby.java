package kingdom.gemMine.gems;

public class Ruby implements Valuable
{
  @Override public String getName()
  {
    return "Ruby";
  }

  @Override public int getValue()
  {
    return 25;
  }
}
