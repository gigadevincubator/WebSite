package kingdom.gemMine.gems;

public class Salt implements Valuable
{
  @Override public String getName()
  {
    return "Salt";
  }

  @Override public int getValue()
  {
    return 20;
  }
}
