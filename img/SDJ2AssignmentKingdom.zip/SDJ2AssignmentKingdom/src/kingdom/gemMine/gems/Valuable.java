package kingdom.gemMine.gems;

public interface  Valuable
{

  String getName();
  int getValue();
}
