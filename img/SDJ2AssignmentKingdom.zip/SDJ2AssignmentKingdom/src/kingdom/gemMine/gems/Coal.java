package kingdom.gemMine.gems;

public class Coal implements Valuable
{

  @Override public String getName()
  {
    return "Coal";
  }

  @Override public int getValue()
  {
    return 5;
  }
}
