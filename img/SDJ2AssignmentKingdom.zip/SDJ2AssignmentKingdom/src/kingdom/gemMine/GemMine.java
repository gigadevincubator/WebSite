package kingdom.gemMine;

import kingdom.gemMine.gems.*;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class GemMine
{
  private static Map<String, Valuable> valuables = new HashMap<>();

  public static Valuable getValuable(String valuableType)
  {
    Valuable valuable = valuables.get(valuableType);

    if (valuable == null)
    {
      synchronized (valuables)
      {
        valuable = valuables.get(valuableType);
        if (valuable == null)
        {
          switch (valuableType)
          {
            case "coal":
            {
              valuable = new Coal();
              break;
            }
            case "diamond":
            {
              valuable = new Diamond();
              break;
            }
            case "goldNugget":
            {
              valuable = new GoldNugget();
              break;
            }
            case "ironNugget":
            {
              valuable = new IronNugget();
              break;
            }
            case "ruby":
            {
              valuable = new Ruby();
              break;
            }
            case "salt":
              valuable = new Salt();
              break;
          }
          valuables.put(valuableType, valuable);
        }
      }
    }
    return valuable;
  }

}
