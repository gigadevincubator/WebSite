package kingdom.castle;

import kingdom.gemMine.gems.Valuable;

import java.util.List;

public interface TreasureRoomDoor {

    void acquireReadAccess(String actorName) throws Exception;

    void acquireWriteAccess(String actorName) throws Exception;

    void releaseReadAccess(String actorName);

    void releaseWriteAccess(String actorName);

    Valuable retrieveValuable();

    void addValuable(Valuable v);

    List<Valuable> lookAtAllGems();

}
