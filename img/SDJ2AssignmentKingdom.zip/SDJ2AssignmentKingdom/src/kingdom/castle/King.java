package kingdom.castle;

import kingdom.Catalogue;
import kingdom.gemMine.gems.Valuable;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class King implements Runnable
{

  Random random = new Random();
  TreasureRoomDoor treasureRoom;
  private Catalogue catalogue;
  private ArrayList<Valuable> kingsPocket;

  public King(TreasureRoomGuardsman treasureRoom)
  {
    this.treasureRoom = treasureRoom;
    catalogue = Catalogue.getCatalogue();
    kingsPocket = new ArrayList<>();
  }

  @Override public void run()
  {
    while (true)
    {
      int partyExpenses = random.nextInt(101) + 50;
      int kingsPocketValue = 0;
      if (treasureRoom.lookAtAllGems().size() != 0)
      {
        try
        {
          treasureRoom.acquireWriteAccess("King");
        }
        catch (Exception e)
        {
          catalogue.writeToCatalogue(e.getMessage());
        }

        for (int i = 0; i < treasureRoom.lookAtAllGems().size(); i++)
        {
          Valuable valuable = treasureRoom.retrieveValuable();
          kingsPocket.add(valuable);
          kingsPocketValue += valuable.getValue();
          if(kingsPocketValue > partyExpenses)
          {
            break;
          }
        }
        if (partyExpenses > kingsPocketValue)
        {
          for (int j = 0; j < kingsPocket.size(); j++)
          {
            treasureRoom.addValuable(kingsPocket.get(0));
            kingsPocket.remove(0);
          }
          catalogue.writeToCatalogue(
              "The king puts the gems back in disgust. No party will be thrown. The king is angry and the executioner is sharpening his axe. There WILL be consequences.");
          treasureRoom.releaseWriteAccess("King");
        }
        else
        {
          catalogue.writeToCatalogue(
              "'TONIGHT IS THE NIGHT!', yells the king, looking forward to enjoying a night of debauchery with his many courtesans and rivers of wine");
          treasureRoom.releaseWriteAccess("King");
        }
        try
        {
          Thread.sleep(8000);
        }
        catch (InterruptedException e)
        {
          e.printStackTrace();
        }
      }
    }
  }
}

