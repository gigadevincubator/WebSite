package kingdom.castle;

import kingdom.Catalogue;
import kingdom.utils.ArrayList;
import kingdom.gemMine.gemDeposit.GemDeposit;
import kingdom.gemMine.gems.Valuable;

import java.util.Random;

public class GemTransporter implements Runnable
{
  private Random random = new Random();
  private GemDeposit gemDeposit;
  private ArrayList<Valuable> backpack;
  private Catalogue catalogue;
  private TreasureRoomDoor treasureRoom;

  public GemTransporter(GemDeposit gemDeposit,
      TreasureRoomGuardsman treasureRoom)
  {
    this.gemDeposit = gemDeposit;
    backpack = new ArrayList<>();
    this.catalogue = Catalogue.getCatalogue();
    this.treasureRoom = treasureRoom;
  }

  @Override public void run()
  {
    while (true)
    {
      int valueToAchieve = random.nextInt(151) + 50;
      int achievedValue = 0;
      while (achievedValue < valueToAchieve)
      {
        Valuable valuable = gemDeposit.take();
        backpack.add(valuable);
        achievedValue += valuable.getValue();
      }
      catalogue.writeToCatalogue(
          "The transporter has a full backpack and is on his way back to the castle!");
      //Gem Transporter is on his way to the castle.
      try
      {
        Thread.sleep(3000);
      }
      catch (InterruptedException e)
      {
        e.printStackTrace();
      }
      try
      {
        treasureRoom.acquireWriteAccess("Gem Transporter");
      }
      catch (Exception e)
      {
        catalogue.writeToCatalogue(e.getMessage());
        break;
      }
      while (backpack.size() > 1)
      {
        treasureRoom.addValuable(backpack.get(0));
        backpack.remove(0);
      }
      treasureRoom.releaseWriteAccess("Gem Transporter");
        try
        {
          Thread.sleep(5000);
        }
        catch (InterruptedException e)
        {
          e.printStackTrace();
        }
      }
    }
  }
