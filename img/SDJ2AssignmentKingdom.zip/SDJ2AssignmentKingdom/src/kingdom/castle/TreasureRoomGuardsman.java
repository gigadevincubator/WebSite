package kingdom.castle;

import kingdom.Catalogue;
import kingdom.gemMine.gems.Valuable;

import java.util.ArrayList;
import java.util.List;

/**
 * We decided to use the reader preference for the reader/writer problem
 */

public class TreasureRoomGuardsman implements TreasureRoomDoor
{

  private int waitingReaders;
  private int activeReaders;
  private boolean activeWriter;


  private static ArrayList<String> canPass;

  private TreasureRoomDoor treasureRoom = new TreasureRoom();

  public TreasureRoomGuardsman()
  {
    canPass = new ArrayList<>();
    canPass.add("Accountant");
    canPass.add("Gem Transporter");
    canPass.add("King");
  }


  @Override public synchronized void acquireReadAccess(String actorName)
      throws Exception
  {
    if (canPass.contains(actorName))
    {
      waitingReaders++;
      while (activeWriter)
      {
        try
        {
          wait();
        }
        catch (InterruptedException ignored) {}
      }
      waitingReaders--;
      activeReaders++;
      treasureRoom.acquireReadAccess(actorName);
    }
    else
    {
      throw new Exception(actorName + " has tried to enter the treasury and was dismembered by the guardsman!");
    }
  }

  @Override public synchronized void acquireWriteAccess(String actorName)
      throws Exception
  {
    if (canPass.contains(actorName))
    {
      while (activeReaders > 0 || activeWriter || waitingReaders > 0)
      {
        try
        {
          wait();
        }
        catch (InterruptedException ignored){}
      }
      activeWriter = true;
      treasureRoom.acquireWriteAccess(actorName);
    }
    else
    {
      throw new Exception(actorName + " has tried to enter the treasury and was dismembered by the guardsman!");
    }
  }

  @Override public synchronized void releaseReadAccess(String actorName)
  {
    activeReaders--;
    if(activeReaders==0)
    {
      notifyAll();
    }
    treasureRoom.releaseReadAccess(actorName);
  }

  @Override public synchronized void releaseWriteAccess(String actorName)
  {
    activeWriter = false;
    notifyAll();
    treasureRoom.releaseWriteAccess(actorName);
  }

  @Override public Valuable retrieveValuable()
  {
    return treasureRoom.retrieveValuable();
  }

  @Override public void addValuable(Valuable v)
  {
    treasureRoom.addValuable(v);
  }

  @Override public List<Valuable> lookAtAllGems()
  {
    return treasureRoom.lookAtAllGems();
  }
}
