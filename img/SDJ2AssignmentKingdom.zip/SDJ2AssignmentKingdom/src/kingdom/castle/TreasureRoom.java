package kingdom.castle;
import kingdom.Catalogue;
import kingdom.gemMine.gems.Valuable;

import java.util.ArrayList;
import java.util.List;

public class TreasureRoom implements TreasureRoomDoor {
    private List<Valuable> gems;
    Catalogue catalogue;

    public TreasureRoom() {
        gems = new ArrayList<>();
        catalogue = Catalogue.getCatalogue();
    }

    // access methods

    public synchronized void acquireReadAccess(String actorName) {
        catalogue.writeToCatalogue("The guard gives the " + actorName + " a long intimidating look and then opens the door to the treasury.");
    }

    public synchronized void acquireWriteAccess(String actorName) {
        if (actorName.equals("Gem Transporter"))
        {
            catalogue.writeToCatalogue(
                "The guard is happy to see the gem transporter approaching and quickly opens the door to the treasury.");
        }
        else if (actorName.equals("King"))
        {
          catalogue.writeToCatalogue("'ALL HAIL THE KING!', shouts the guard as the King enters the treasury.");
        }
    }

    public synchronized void releaseReadAccess(String actorName) {
        catalogue.writeToCatalogue("The " + actorName + " has left the treasury!");
    }

    public synchronized void releaseWriteAccess(String actorName) {
        if(actorName.equals("Gem Transporter"))
        {
            catalogue.writeToCatalogue("The gem transporter dumps the valuables and leaves in a hurry. Can't have the king waiting!");
        }
        else
        {
            catalogue.writeToCatalogue("His grace the " + actorName + " has left the treasury!");
        }
    }

    // interact methods

    public synchronized Valuable retrieveValuable() {
        Valuable v = null;
        if (gems.size() > 0) {
            v = gems.remove(0);
        }
        return v;
    }

    public synchronized void addValuable(Valuable v) {
        gems.add(v);
    }

    @Override
    public synchronized ArrayList<Valuable> lookAtAllGems() {
        return new ArrayList<Valuable>(gems);

    }
}