package kingdom.castle;

import kingdom.Catalogue;
import kingdom.gemMine.gems.Valuable;

import java.util.List;

public class Accountant implements Runnable
{

  private TreasureRoomDoor treasureRoom;
  private Catalogue catalogue;
  private int valueOfGemsInTreasureRoom = 0;

  public Accountant(TreasureRoomGuardsman treasureRoom)
  {
    this.treasureRoom = treasureRoom;
    catalogue = Catalogue.getCatalogue();
  }

  @Override public void run()
  {
    while (true)
    {
      try
      {
        treasureRoom.acquireReadAccess("Accountant");
      }
      catch (Exception e){
        catalogue.writeToCatalogue(e.getMessage());
        break;
      }
        for (int i = 0; i < treasureRoom.lookAtAllGems().size(); i++)
        {
          valueOfGemsInTreasureRoom += treasureRoom.lookAtAllGems().get(i).getValue();
        }
        //Accountant calculating
        try
        {
          Thread.sleep(4000);
        }
        catch (InterruptedException e)
        {
          e.printStackTrace();
        }
        catalogue.writeToCatalogue("The accountant has estimated the value of the treasury to be " + valueOfGemsInTreasureRoom + "!" );
        treasureRoom.releaseReadAccess("Accountant");
        try
        {
          Thread.sleep(15000);
        }
        catch (InterruptedException e)
        {
          e.printStackTrace();
      }
    }
  }
}
