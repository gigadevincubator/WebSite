package kingdom;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Catalogue
{
  private static Catalogue catalogue;
  private static final Lock lock = new ReentrantLock();


  private Catalogue()
  {

  }

  public static Catalogue getCatalogue()
  {
    if (catalogue == null)
    {
      synchronized (lock)
      {
        if (catalogue == null)
        {
          catalogue = new Catalogue();
        }
      }
    }
    return catalogue;
  }

  public void writeToCatalogue(String message)
  {
    System.out.println(message);
  }
}
