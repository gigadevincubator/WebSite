package kingdom.utils;

public class ArrayListQueue<T> implements QueueADT<T>
{
    private ListADT<T> queue = new ArrayList<>();

    @Override
    public void enqueue(T element) {
        queue.add(element);
    }

    @Override
    public T dequeue() {
        return queue.remove(0);
    }

    @Override
    public T first() {
        return queue.get(0);
    }

    @Override
    public boolean isEmpty() {
        return queue.isEmpty();
    }

    @Override
    public boolean isFull() {
        return queue.isFull();
    }

    @Override
    public int size() {
        return queue.size();
    }
}
