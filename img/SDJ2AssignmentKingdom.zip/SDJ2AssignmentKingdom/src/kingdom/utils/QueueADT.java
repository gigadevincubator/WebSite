package kingdom.utils;

public interface QueueADT<T>
{
    void enqueue(T object);
    T dequeue();
    T first();
    boolean isEmpty();
    boolean isFull();
    int size();
}
