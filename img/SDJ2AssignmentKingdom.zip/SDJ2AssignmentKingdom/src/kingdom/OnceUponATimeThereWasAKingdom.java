package kingdom;

import kingdom.castle.*;
import kingdom.gemMine.GemMineWorker;
import kingdom.gemMine.gemDeposit.GemDeposit;
import kingdom.gemMine.gemDeposit.GemDepositBlockingQueue;

public class OnceUponATimeThereWasAKingdom
{
  public static void main(String[] args)
  {
    GemDeposit deposit = new GemDepositBlockingQueue(50);
    TreasureRoomGuardsman treasureRoomGuardsman = new TreasureRoomGuardsman();

    GemMineWorker worker1 = new GemMineWorker(deposit);
    GemMineWorker worker2 = new GemMineWorker(deposit);
    GemMineWorker worker3 = new GemMineWorker(deposit);
    GemMineWorker worker4 = new GemMineWorker(deposit);

    King king = new King(treasureRoomGuardsman);

    GemTransporter transporter1 = new GemTransporter(deposit, treasureRoomGuardsman);
    GemTransporter transporter2 = new GemTransporter(deposit, treasureRoomGuardsman);

    Accountant accountant1 = new Accountant(treasureRoomGuardsman);
    new Thread(worker1).start();
    new Thread(worker2).start();
    new Thread(worker3).start();
    new Thread(worker4).start();

    new Thread(transporter1).start();
    new Thread(transporter2).start();

    new Thread(accountant1).start();

    new Thread(king).start();
  }
}
