import kingdom.utils.ArrayList;
import kingdom.utils.ListADT;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ListTest
{

  private static ListADT<Object> list;

  //Setting up the array list
  @BeforeEach
  public void setup()
  {
    list = new ArrayList<>();
  }

  //Testing the size first, so that I'm sure that one works
  @Test
  public void addZero()
  {
    assertEquals(0,list.size());
  }

  //Here I test whether the method can add 1 element to the list
  @Test
  public void addOne()
  {
    list.add("A");
    assertEquals(1,list.size());
  }

  //Here I test whether the method can add many elements to the list
  @Test
  public void addMany()
  {
    list.add("A");
    list.add("B");
    list.add("C");
    list.add("D");
    list.add("E");
    assertEquals(5, list.size());
  }

  //Testing if the add method throws IllegalArgumentException if the object element passed is null (ha found it!)
  @Test
  public void add_IllegalArgumentException()
  {
    assertThrows(IllegalArgumentException.class, ()-> list.add(null));
  }

  //Testing if the add method throws IndexOutOfBoundsException if the index is out of bounds
  @Test
  public void add_IndexOutOfBoundsException()
  {
    assertThrows(IndexOutOfBoundsException.class, ()->list.add(-1,"A"));
  }



  //Testing if the contains method returns false if it doesn't contain the element
  @Test
  public void contains_WhenDoesNotContainElement()
  {
    assertFalse(list.contains("A"));
  }
  //Testing if the contains method returns true if it does contain the element
  @Test
  public void contains_WhenContainsElement()
  {
    list.add("A");
    assertTrue(list.contains("A"));
  }
  //Testing if the get returns the correct element
  @Test
  public void get_ReturnsCorrectElement()
  {
    list.add("A");
    assertEquals("A",list.get(0));
  }

  //Testing if the get method throws indexOutOfBoundsException if the index is out of bounds
  @Test
  public void get_IndexOutOfBoundsException()
  {
    assertThrows(IndexOutOfBoundsException.class, ()-> list.get(-1));
  }

  //Testing if index of returns the correct index
  @Test
  public void indexOf_ReturnsTheCorrectIndex()
  {
    list.add("A");
    assertEquals(0, list.indexOf("A"));
  }

  //Testing if isEmpty() returns true if the list is empty
  @Test
  public void isEmpty_ReturnsTrue_IfIsEmpty()
  {
    assertTrue(list.isEmpty());
  }

  //Testing if isEmpty() returns false if the list is not empty
  @Test
  public void isEmpty_ReturnsFalse_IfIsNotEmpty()
  {
    list.add("A");
    assertFalse(list.isEmpty());
  }

  //Testing if isFull() returns false if the list is not full
  @Test
  public void isFull_ReturnsFalse_IfIsNotFull()
  {
    assertFalse(list.isFull());
  }

  //Testing if remove(int index) removes element from the list
  @Test
  public void removeWithIndexParameter_RemovesElementFromList()
  {
    list.add("A");
    list.remove(0);
    assertEquals(0,list.size());
  }

  //Testing if remove(int index) returns the correct element from the list
  @Test
  public void removeWithIndexParameter_ReturnsCorrectElement()
  {
    list.add("A");
    assertEquals("A", list.remove(0));
  }

  //Testing IndexOutOfBoundsException for remove(int index)
  @Test
  public void removeWithIndexParameter_IndexOutOfBoundsException()
  {
    assertThrows(IndexOutOfBoundsException.class, ()-> list.remove(-1));
  }

  //Testing if remove(T element) removes element from the list
  @Test
  public void removeWithElementParameter_RemovesElementFromList()
  {
    list.add("A");
    list.remove("A");
    assertEquals(0,list.size());
  }

  //Testing if remove(T element) returns the correct element from the list
  @Test
  public void removeWithElementParameter_ReturnsCorrectElement()
  {
    list.add("A");
    assertEquals("A", list.remove("A"));
  }

  //Testing if set() sets the element at the correct index
  @Test
  public void set_SetsTheElementAtTheCorrectIndex()
  {
    list.add(0,"A");
    list.add(1,"B");
    list.set(1,"A");
    assertEquals(1, list.indexOf("A"));
  }

  //Testing IndexOutOfBoundsException for set()
  @Test
  public void set_IndexOutOfBoundsException()
  {
    assertThrows(IndexOutOfBoundsException.class, ()-> list.set(-1,"A"));
  }
  //Testing IllegalArgumentException for set()
  @Test
  public void set_IllegalArgumentException()
  {
    assertThrows(IllegalArgumentException.class, ()->list.set(1,null));
  }
}